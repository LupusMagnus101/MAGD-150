let img1, img2, transparentImg;

function preload() {
 
  img1 = loadImage('WIN_20241030_14_57_11_Pro.jpg');  

  img2 = loadImage('WIN_20241030_14_57_09_Pro.jpg');  

  transparentImg = loadImage('WIN_20241030_14_57_09_Pro.jpg');  

}

function setup() {

  createCanvas(400, 400);

  textFont('Helvetica');  // Set
}


function draw() {

  background(220);




  image(img1, 50, 50, mouseX / 2, mouseY / 2); 




  image(img2, mouseX, mouseY, 100, 100);  



 
  image(transparentImg, mouseX - 50, mouseY - 50, 80, 80); 


 

  fill(0, 102, 153);  

  stroke(255, 204, 0);  

  strokeWeight(2);  

  textSize(24);  

  text('Zachary Was the best programmer ever', 10, 300, 380, 100);  // Specify width and height constraints
}
