

function setup() {
  
  createCanvas(400, 400);
  
  //trying something with degrees 
  
  angleMode(DEGREES); 
  
  // need to stop draw function
  noLoop();                
}

function draw() {
  
  background(220);         
  
  // for loop 
  for (let i = 0; i < 5; i++) {
    
    push();               
    
    //contoles the x and y
    translate(random(width), random(height));
    
    // type of size the clouds woulds  be
    
    scale(random(0.5, 1.5));    
    
    rotate(random(360));
    
    
    drawCloudShape();          
    
    
    pop();                 
    
  }
// something fun 
  
  let result = calculateSomething();  
  
  print(result);                     
}

function drawCloudShape() {
 
  fill(255);
  
  stroke(5);           
  

  ellipse(0, 0, 60, 60);  
  
  ellipse(-30, -20, 50, 50); 
  
  ellipse(30, -20, 50, 50);  
  
  ellipse(-45, 10, 40, 40);  
  
  ellipse(45, 10, 40, 40);  
  
}


//returns a value
function calculateSomething() {
  
  let randomValue = random(1, 100); 
  
  return randomValue;               
}
